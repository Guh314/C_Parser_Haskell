module Main where
import parsec


type Code = [Statement]

data Statement
    = Print Var
    | Assign DataType VarName Val
    | While Cond Var
    | Op Var Var
    deriving (Eq, Show)

type Var = String


-- Parser :: String -> Code
-- CodeGen :: Code -> String IO()


main :: IO ()
main = putStrLn "Hello, Haskell!"
